**To remove an account from an organization as the master account**

The following example shows you how to remove an account from an organization: ::

    aws organizations remove-account-from-organization --account-id 333333333333
