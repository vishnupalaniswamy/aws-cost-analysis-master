The following command cancels the specified job::

  aws importexport cancel-job --job-id EX1ID

Only jobs that were created by the AWS account you're currently using can be canceled. Jobs that have already completed cannot be canceled.
